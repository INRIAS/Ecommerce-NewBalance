// function mostrar(){
//     document.getElementById("mos").style.transition="block 2s";
//     document.getElementById("mos").style.display="block";

// }

// function ocultar(){
//     document.getElementById("mos").style.display="none";
//     document.getElementById("mos").style.transition="2s";

// }

// document.getElementById("dataPersona").addEventListener("webkitTransitionEnd", myFunction);
// document.getElementById("dataPersona").addEventListener("transitionend", myFunction);
// function myFunction() {
//     this.innerHTML="Evento de transición activado: la transición se ha completado";
//     this.style.backgroundColor="deeppink";
// }